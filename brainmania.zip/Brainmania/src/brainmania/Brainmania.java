/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package brainmania;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView; 
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author mypc
 */
public class Brainmania extends Application {
    
    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {
        Image logo = new Image(new FileInputStream("images/BrainMania.png"));
        ImageView logo_view = new ImageView(logo);
        logo_view.setFitHeight(50); 
        logo_view.setFitWidth(200);
        GridPane.setConstraints(logo_view, 0, 0);
        

        Label name_lbl=new Label("Enter Nickname");
        name_lbl.setFont(Font.font ("Century Gothic",FontWeight.BOLD,18));
        name_lbl.setStyle("-fx-text-fill:BLACK");
        GridPane.setConstraints(name_lbl, 0, 2);
        
        final TextField name_txt=new TextField();
        name_txt.setPromptText("Enter your nickname!!");
        name_txt.getText();
        name_txt.setFont(Font.font ("Century Gothic"));
        name_txt.setStyle("-fx-text-box-border:BLACK; -fx-focus-color:BLACK;");
        GridPane.setConstraints(name_txt, 0, 3);
        
        Button btn = new Button();
        btn.setText("Lets Brain");
        btn.setFont(Font.font ("Century Gothic",FontWeight.BOLD,16)); 
        btn.setStyle("-fx-background-color: BLACK; -fx-text-fill: WHITE;");
        GridPane.setConstraints(btn, 0, 4);
        
        btn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                System.out.println(name_txt.getText());
            }
        });
        
        GridPane name_grid=new GridPane();
        name_grid.setPadding(new Insets(10, 10, 10, 10));
        name_grid.setAlignment(Pos.CENTER);
        name_grid.setVgap(5);
        name_grid.setHgap(5);
        name_grid.setStyle("-fx-background-color: CADETBLUE");
        name_grid.getChildren().addAll(logo_view,name_lbl,name_txt,btn);   
        
        Scene scene = new Scene(name_grid, 500, 500);
        
        primaryStage.setTitle("BrainMania");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
